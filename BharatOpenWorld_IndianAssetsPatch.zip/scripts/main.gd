extends Node2D

# Bharat Open World — Naya Nagar Indian asset pass (Godot 4.3)
# Uses original Indian-inspired sprites plus Kenney's CC0 RPG Urban tiles.

const SAVE_PATH := "user://bharat_save.json"
const WORLD_SIZE := Vector2(2200, 2600)
const PLAYER_SPEED := 175.0
const VEHICLE_SPEED := 260.0

var player_pos := Vector2(1100, 1280)
var player_dir := Vector2.DOWN
var vehicle_pos := Vector2(1190, 1280)
var in_vehicle := false
var mission_stage := 0
var cash := 250
var health := 100
var elapsed := 0.0
var message := "Welcome to Naya Nagar! Visit the chai stall."
var message_time := 6.0
var move_vector := Vector2.ZERO
var joystick_touch := -1
var joystick_origin := Vector2.ZERO
var joystick_current := Vector2.ZERO
var interaction_requested := false
var save_requested := false
var npc_positions: Array[Vector2] = []
var npc_home: Array[Vector2] = []
var buildings: Array[Rect2] = []
var trees: Array[Vector2] = []
var lamps: Array[Vector2] = []
var road_rects: Array[Rect2] = []
var stall_rect := Rect2(1280, 1190, 128, 96)
var mission_target := Vector2(1344, 1240)
var camera_pos := Vector2.ZERO
var screen_size := Vector2(480, 854)
var textures: Dictionary = {}
var ui_textures: Dictionary = {}
var font: Font
var sound_player: AudioStreamPlayer

func _ready() -> void:
    randomize()
    font = ThemeDB.fallback_font
    sound_player = AudioStreamPlayer.new()
    add_child(sound_player)
    _load_art()
    _build_world()
    _load_game()
    set_process(true)
    set_process_input(true)

func _load_art() -> void:
    var art_names := ["chai_stall", "kirana_shop", "auto_rickshaw", "scooter", "banyan_tree", "pedestrian_kurta", "pedestrian_sari", "pedestrian_vendor", "hindi_sign", "street_cart", "street_lamp"]
    for art_name in art_names:
        textures[art_name] = load("res://assets/indian/" + art_name + ".png")
    # Kenney RPG Urban Pack sprites: small 16px sprites scaled with nearest-neighbour filtering.
    for tile_id in [22, 23, 24, 25, 26, 49, 50, 51, 52, 53, 77, 78, 79, 80, 104, 105, 106, 107, 131, 132, 133, 134, 184, 185, 186, 187, 212, 213, 214, 215, 232, 233, 234, 235, 236, 237, 238, 239, 258, 259, 260, 261, 262, 263, 420, 421, 422, 423, 424, 425, 426, 427, 474, 475, 476, 477, 478, 479, 480, 481]:
        var path := "res://assets/kenney_rpg_urban/Tiles/tile_%04d.png" % tile_id
        textures["kenney_%d" % tile_id] = load(path)
    ui_textures["action"] = load("res://assets/ui/buttonRound_brown.png")
    ui_textures["save"] = load("res://assets/ui/buttonRound_blue.png")

func _build_world() -> void:
    road_rects = [
        Rect2(0, 1030, WORLD_SIZE.x, 170),
        Rect2(900, 0, 170, WORLD_SIZE.y),
        Rect2(0, 1530, WORLD_SIZE.x, 140),
        Rect2(400, 400, 140, 850),
        Rect2(1370, 700, 140, 850)
    ]
    buildings = [
        Rect2(560, 850, 210, 170), Rect2(1120, 790, 200, 170),
        Rect2(1510, 880, 190, 150), Rect2(570, 1260, 190, 150),
        Rect2(1570, 1270, 200, 150), Rect2(560, 1750, 210, 160),
        Rect2(1050, 1810, 250, 150), Rect2(1510, 1770, 220, 170),
        Rect2(800, 2150, 220, 170), Rect2(1330, 2200, 230, 160)
    ]
    npc_home = [Vector2(800,1150), Vector2(1000,1400), Vector2(1450,1430), Vector2(1220,970), Vector2(900,1730), Vector2(1690,1580), Vector2(1160,1320), Vector2(730,1590)]
    npc_positions = npc_home.duplicate()
    trees.clear()
    lamps.clear()
    for i in range(72):
        var p := Vector2(randf_range(45, WORLD_SIZE.x - 45), randf_range(50, WORLD_SIZE.y - 50))
        if _is_on_road(p) or _near_building(p, 100) or p.distance_to(player_pos) < 160:
            continue
        trees.append(p)
    for i in range(30):
        var p := Vector2(randf_range(100, WORLD_SIZE.x-100), randf_range(100, WORLD_SIZE.y-100))
        if _is_on_road(p): lamps.append(p)

func _is_on_road(p: Vector2) -> bool:
    for r in road_rects:
        if r.has_point(p): return true
    return false

func _near_building(p: Vector2, margin: float) -> bool:
    for r in buildings:
        if r.grow(margin).has_point(p): return true
    return stall_rect.grow(margin).has_point(p)

func _process(delta: float) -> void:
    elapsed += delta
    if message_time > 0.0: message_time -= delta
    var input_dir := move_vector
    if Input.is_action_pressed("ui_left"): input_dir.x -= 1.0
    if Input.is_action_pressed("ui_right"): input_dir.x += 1.0
    if Input.is_action_pressed("ui_up"): input_dir.y -= 1.0
    if Input.is_action_pressed("ui_down"): input_dir.y += 1.0
    input_dir = input_dir.limit_length()
    if input_dir.length() > 0.05:
        player_dir = input_dir.normalized()
        var speed := VEHICLE_SPEED if in_vehicle else PLAYER_SPEED
        var candidate := player_pos + input_dir.normalized() * speed * delta
        if not _blocked(candidate): player_pos = candidate
        if in_vehicle: vehicle_pos = player_pos
    for i in range(npc_positions.size()):
        var home: Vector2 = npc_home[i]
        npc_positions[i] = home + Vector2(sin(elapsed * 0.55 + i) * 16.0, cos(elapsed * 0.45 + i) * 9.0)
    if interaction_requested:
        interaction_requested = false
        _interact()
    if save_requested:
        save_requested = false
        _save_game()
        _play_sound("metalClick")
        _show_message("Game saved on this device.")
    queue_redraw()

func _blocked(p: Vector2) -> bool:
    if p.x < 20 or p.y < 20 or p.x > WORLD_SIZE.x-20 or p.y > WORLD_SIZE.y-20: return true
    for r in buildings:
        if r.grow(8).has_point(p): return true
    if stall_rect.grow(8).has_point(p): return true
    return false

func _interact() -> void:
    if player_pos.distance_to(vehicle_pos) < 76 and not in_vehicle:
        in_vehicle = true
        _play_sound("metalClick")
        player_pos = vehicle_pos
        _show_message("Scooter ready! Use the joystick to ride.")
        return
    if in_vehicle:
        in_vehicle = false
        player_pos += Vector2(48, 0)
        _show_message("Scooter parked.")
        return
    if player_pos.distance_to(mission_target) < 200:
        if mission_stage == 0:
            mission_stage = 1
            _show_message("Chaiwala: deliver chai to the station worker!")
        elif mission_stage == 1:
            mission_stage = 2
            cash += 150
            _play_sound("handleCoins")
            _show_message("Delivery complete! You earned ₹150.")
        else:
            _show_message("Chaiwala: fresh chai, come again!")
    else:
        _show_message("Find the yellow marker near the chai stall.")

func _play_sound(sound_name: String) -> void:
    var sound_path := "res://assets/audio/" + sound_name + ".ogg"
    if ResourceLoader.exists(sound_path):
        sound_player.stream = load(sound_path)
        sound_player.play()

func _show_message(text_value: String) -> void:
    message = text_value
    message_time = 4.5

func _save_game() -> void:
    var data := {"player_x":player_pos.x,"player_y":player_pos.y,"vehicle_x":vehicle_pos.x,"vehicle_y":vehicle_pos.y,"cash":cash,"health":health,"mission_stage":mission_stage,"in_vehicle":in_vehicle}
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(data))
        f.close()

func _load_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH): return
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if not f: return
    var parsed = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(parsed) == TYPE_DICTIONARY:
        player_pos = Vector2(float(parsed.get("player_x",player_pos.x)),float(parsed.get("player_y",player_pos.y)))
        vehicle_pos = Vector2(float(parsed.get("vehicle_x",vehicle_pos.x)),float(parsed.get("vehicle_y",vehicle_pos.y)))
        cash = int(parsed.get("cash",cash)); health = int(parsed.get("health",health))
        mission_stage = int(parsed.get("mission_stage",mission_stage)); in_vehicle = bool(parsed.get("in_vehicle",in_vehicle))

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_E or event.keycode == KEY_SPACE: interaction_requested = true
        elif event.keycode == KEY_F5: save_requested = true
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < screen_size.x * 0.52 and event.position.y > screen_size.y * 0.55:
                joystick_touch = event.index; joystick_origin = event.position; joystick_current = event.position; _update_joystick()
            elif event.position.x > screen_size.x * 0.72 and event.position.y > screen_size.y * 0.55:
                if event.position.y < screen_size.y * 0.78: interaction_requested = true
                else: save_requested = true
        elif event.index == joystick_touch:
            joystick_touch = -1; move_vector = Vector2.ZERO
    elif event is InputEventScreenDrag and event.index == joystick_touch:
        joystick_current = event.position; _update_joystick()

func _update_joystick() -> void:
    move_vector = ((joystick_current - joystick_origin) / 55.0).limit_length()
    if move_vector.length() < 0.16: move_vector = Vector2.ZERO

func _sprite(name: String, rect: Rect2, centered: bool = false) -> void:
    var tex = textures.get(name)
    if tex == null: return
    var target := rect
    if centered: target.position -= target.size * 0.5
    draw_texture_rect(tex, target, false)

func _kenney(tile_id: int, center: Vector2, size: Vector2) -> void:
    var tex = textures.get("kenney_%d" % tile_id)
    if tex != null: draw_texture_rect(tex, Rect2(center - size * 0.5, size), false)

func _draw() -> void:
    screen_size = get_viewport_rect().size
    camera_pos = player_pos - screen_size * 0.5
    camera_pos.x = clamp(camera_pos.x, 0.0, WORLD_SIZE.x-screen_size.x)
    camera_pos.y = clamp(camera_pos.y, 0.0, WORLD_SIZE.y-screen_size.y)
    draw_set_transform(-camera_pos, 0.0, Vector2.ONE)
    _draw_world()
    _draw_entities()
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    _draw_hud()

func _draw_world() -> void:
    draw_rect(Rect2(Vector2.ZERO,WORLD_SIZE),Color("#4b9867"))
    # Textured grass and small vegetation speckles keep the map from looking flat.
    var start_x := int(camera_pos.x / 32.0) * 32
    var start_y := int(camera_pos.y / 32.0) * 32
    var end_x := int(min(camera_pos.x + screen_size.x + 32.0, WORLD_SIZE.x))
    var end_y := int(min(camera_pos.y + screen_size.y + 32.0, WORLD_SIZE.y))
    for x in range(start_x,end_x,32):
        for y in range(start_y,end_y,32):
            if ((int(x / 32.0) + int(y / 32.0)) % 3) == 0:
                draw_rect(Rect2(x+5,y+8,3,3),Color("#3d8058"))
            elif ((int(x / 32.0) + int(y / 32.0)) % 5) == 0:
                draw_rect(Rect2(x+21,y+22,2,2),Color("#8cbd69"))
    # Road shoulders, asphalt and painted lane markings.
    for r in road_rects:
        draw_rect(r.grow(18),Color("#c8b38a"))
        draw_rect(r.grow(7),Color("#ded0a6"))
        draw_rect(r,Color("#555b63"))
        if r.size.x > r.size.y:
            for x in range(int(r.position.x),int(r.end.x),74):
                draw_rect(Rect2(x,r.position.y+r.size.y*0.5-2,35,4),Color("#f2dca0"))
        else:
            for y in range(int(r.position.y),int(r.end.y),74):
                draw_rect(Rect2(r.position.x+r.size.x*0.5-2,y,4,35),Color("#f2dca0"))
    # Buildings with real sprite façades, Hindi signs, awnings and door details.
    for i in range(buildings.size()):
        var b: Rect2 = buildings[i]
        draw_rect(b.grow(10),Color("#bda77d"))
        draw_rect(Rect2(b.position+Vector2(3,6),b.size),Color("#4b3933"))
        var shop_name := "kirana_shop" if i % 3 != 1 else "kirana_shop"
        _sprite(shop_name,Rect2(b.position+Vector2(0,0),b.size))
        # Façade window highlights and entry step.
        for wx in range(int(b.position.x+22),int(b.end.x-15),48):
            draw_rect(Rect2(wx,b.position.y+36,22,23),Color("#7eb4b3"),true)
            draw_rect(Rect2(wx+3,b.position.y+39,16,17),Color("#b9e0d5"),true)
        draw_rect(Rect2(b.position.x+b.size.x*0.42,b.end.y-15,b.size.x*0.16,15),Color("#65412e"))
        if i % 2 == 0:
            _sprite("hindi_sign",Rect2(b.position+Vector2(8,5),Vector2(96,24)))
    # Main chai stall is the mission landmark.
    _sprite("chai_stall",Rect2(stall_rect.position-Vector2(8,0),Vector2(144,112)))
    _sprite("hindi_sign",Rect2(stall_rect.position+Vector2(10,-18),Vector2(108,28)))
    # Vendor cart, trees and street lights.
    _sprite("street_cart",Rect2(1160,1320,80,64))
    # Reuse the uploaded Kenney urban pack for parked city traffic and ornamental trees.
    _kenney(420,Vector2(840,1000),Vector2(44,44))
    _kenney(425,Vector2(1140,1010),Vector2(44,44))
    _kenney(427,Vector2(1580,1510),Vector2(44,44))
    _kenney(232,Vector2(520,980),Vector2(42,48))
    _kenney(235,Vector2(1760,1090),Vector2(42,48))
    _kenney(259,Vector2(1000,1720),Vector2(42,48))
    for p in trees: _sprite("banyan_tree",Rect2(p-Vector2(32,40),Vector2(64,80)))
    for p in lamps: _sprite("street_lamp",Rect2(p-Vector2(12,24),Vector2(24,48)))
    # A canal and its stone edge at the far east of the neighbourhood.
    draw_rect(Rect2(1900,0,300,WORLD_SIZE.y),Color("#3289bd"))
    for y in range(0,int(WORLD_SIZE.y),42):
        draw_line(Vector2(1920,y+10),Vector2(1960,y+3),Color("#82c9e5"),3)
        draw_line(Vector2(2000,y+25),Vector2(2040,y+18),Color("#82c9e5"),2)
    draw_rect(Rect2(1875,0,25,WORLD_SIZE.y),Color("#b8a68b"))

func _draw_entities() -> void:
    var marker_y := mission_target.y + sin(elapsed*3.0)*5.0
    draw_circle(Vector2(mission_target.x,marker_y-22),20,Color(1.0,0.78,0.16,0.18))
    draw_circle(Vector2(mission_target.x,marker_y-22),11,Color("#ffe16b"))
    draw_string(font,Vector2(mission_target.x-4,marker_y-16),"!",HORIZONTAL_ALIGNMENT_LEFT,-1,17,Color("#493326"))
    # Scooter parked near the player; auto-rickshaw gives the street an Indian identity.
    _sprite("scooter",Rect2(vehicle_pos-Vector2(20,27),Vector2(40,54)))
    _sprite("auto_rickshaw",Rect2(Vector2(1440,1110),Vector2(64,80)))
    for i in range(npc_positions.size()):
        var names := ["pedestrian_kurta","pedestrian_sari","pedestrian_vendor"]
        _sprite(names[i%names.size()],Rect2(npc_positions[i]-Vector2(16,24),Vector2(32,48)))
    draw_ellipse_shadow(player_pos)
    if in_vehicle:
        _sprite("scooter",Rect2(player_pos-Vector2(24,32),Vector2(48,64)))
    else:
        _sprite("pedestrian_kurta",Rect2(player_pos-Vector2(16,24),Vector2(32,48)))

func draw_ellipse_shadow(p: Vector2) -> void:
    draw_rect(Rect2(p.x-12,p.y+14,24,5),Color(0,0,0,0.25))

func _draw_hud() -> void:
    # Safe-area HUD: use available viewport instead of fixed 480x854 dimensions.
    draw_rect(Rect2(8,8,screen_size.x-16,92),Color(0.055,0.075,0.09,0.92),true)
    draw_rect(Rect2(8,8,screen_size.x-16,92),Color("#b97b3d"),false,2.0)
    draw_string(font,Vector2(20,32),"BHARAT OPEN WORLD  •  NAYA NAGAR",HORIZONTAL_ALIGNMENT_LEFT,screen_size.x-40,15,Color("#f5d58a"))
    draw_string(font,Vector2(20,55),"₹%d   HP %d   %s" % [cash,health,"AUTO / SCOOTER" if in_vehicle else "ON FOOT"],HORIZONTAL_ALIGNMENT_LEFT,screen_size.x-40,14,Color.WHITE)
    var objective := "Mission: Talk to the chaiwala" if mission_stage == 0 else ("Mission: Deliver chai to station worker" if mission_stage == 1 else "Mission complete  •  +₹150")
    draw_string(font,Vector2(20,79),objective,HORIZONTAL_ALIGNMENT_LEFT,screen_size.x-40,12,Color("#b9e8c8"))
    if message_time > 0.0:
        draw_rect(Rect2(14,screen_size.y*0.145,screen_size.x-28,56),Color(0.04,0.06,0.08,0.91),true)
        draw_string(font,Vector2(24,screen_size.y*0.145+22),message,HORIZONTAL_ALIGNMENT_LEFT,screen_size.x-48,12,Color.WHITE)
        draw_string(font,Vector2(24,screen_size.y*0.145+42),"LEFT: MOVE     RIGHT: ACTION / SAVE",HORIZONTAL_ALIGNMENT_LEFT,screen_size.x-48,10,Color("#f0c879"))
    var joy_center := joystick_origin if joystick_touch != -1 else Vector2(74,screen_size.y-115)
    draw_circle(joy_center,44,Color(0.1,0.13,0.16,0.42))
    draw_circle(joy_center+(move_vector*25.0),19,Color(0.9,0.86,0.72,0.88))
    if ui_textures.get("action") != null:
        draw_texture_rect(ui_textures["action"],Rect2(screen_size.x-103,screen_size.y-181,74,74),false)
    else: draw_circle(Vector2(screen_size.x-66,screen_size.y-145),36,Color("#b83b31"))
    draw_string(font,Vector2(screen_size.x-91,screen_size.y-140),"ACTION",HORIZONTAL_ALIGNMENT_LEFT,55,10,Color.WHITE)
    if ui_textures.get("save") != null:
        draw_texture_rect(ui_textures["save"],Rect2(screen_size.x-94,screen_size.y-94,56,56),false)
    else: draw_circle(Vector2(screen_size.x-66,screen_size.y-65),28,Color("#27638c"))
    draw_string(font,Vector2(screen_size.x-82,screen_size.y-61),"SAVE",HORIZONTAL_ALIGNMENT_LEFT,40,10,Color.WHITE)
    draw_string(font,Vector2(12,screen_size.y-18),"WASD / arrows • E interact • F5 save",HORIZONTAL_ALIGNMENT_LEFT,screen_size.x-24,10,Color(1,1,1,0.65))
