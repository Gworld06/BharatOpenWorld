# Bharat Open World — Indian Art Asset Patch

This patch upgrades the current Godot 4.3 prototype with an initial Indian-themed art pass:

- Original pixel-art chai stall, kirana shop, Hindi signboard, auto-rickshaw, scooter, banyan tree, street cart, street lamp, and three Indian pedestrian looks.
- The uploaded Kenney RPG Urban Pack tile sprites are copied into `assets/kenney_rpg_urban/Tiles/` and selected pedestrian/car sprites are loaded by the replacement `scripts/main.gd`.
- Kenney RPG UI button textures are used for the on-screen ACTION and SAVE buttons.
- A few Kenney sound effects are wired to interaction, saving, and mission reward events; the uploaded sound pack is included under `assets/audio/`.
- Existing movement, touch controls, chai mission, vehicle interaction, cash, and save/load are retained.

## Apply to the existing GitHub repository

1. Upload this ZIP to the root of `Gworld06/BharatOpenWorld` as `BharatOpenWorld_IndianAssetsPatch.zip` (GitHub will store it as a normal file).
2. Open `.github/workflows/android-apk.yml` and add the step shown in `WORKFLOW-STEP.txt` immediately before `Import project resources`.
3. Commit the workflow change. The next push will build using the new sprites, UI, and sound files from the ZIP.
4. Download and install the APK from the latest successful Actions run.

Alternative: extract this ZIP and manually merge `assets/` and replace `scripts/main.gd` in the repository. The workflow-step method is less work on a phone.

## Notes

- Kenney RPG Urban Pack is CC0; see `assets/kenney_rpg_urban/License.txt`.
- This is an asset integration pass, not a finished GTA-scale game. The urban tiles are generic, so the Indian identity is added through original shopfronts, signage, clothing colours, and the auto-rickshaw. Later passes should add more Indian buildings, traffic, traffic signals, local market props, and character walk cycles.
- All sprites are drawn nearest-neighbour for pixel-art style. The original UI and audio packs remain in the project assets for later expansion.
