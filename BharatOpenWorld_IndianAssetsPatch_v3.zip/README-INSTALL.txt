BHARAT OPEN WORLD — INDIAN ASSET PATCH V3

Contains a replacement scripts/main.gd, project.godot, scenes/main.tscn and original sprite crops made from the provided Indian pixel-art reference sheet.

Upload this ZIP to the repository root as BharatOpenWorld_IndianAssetsPatch_v3.zip. The GitHub Actions workflow must use that exact filename and copy the ZIP's scripts/main.gd, project.godot and assets/indian folder before Godot import.

Assets include: chai stall, kirana shop, terrace homes, temple, banyan/neem trees, lamp, vegetable/flower carts, auto-rickshaw, scooter, motorcycle, hatchback, and 8 Indian pedestrian variants. Ground tiles are generated pixel-art textures.
