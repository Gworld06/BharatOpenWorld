extends Node2D

# Bharat Open World — Naya Nagar visual upgrade.
# Art is loaded from isolated, alpha-cut Indian pixel-art sprites.
const SAVE_PATH: String = "user://bharat_save.json"
const WORLD_SIZE: Vector2 = Vector2(3000.0, 3600.0)
const PLAYER_SPEED: float = 175.0
const SCOOTER_SPEED: float = 300.0
const TILE_SIZE: float = 64.0

var textures: Dictionary = {}
var player_pos: Vector2 = Vector2(1480.0, 1500.0)
var player_dir: Vector2 = Vector2.DOWN
var scooter_pos: Vector2 = Vector2(1390.0, 1570.0)
var auto_pos: Vector2 = Vector2(1780.0, 1225.0)
var in_vehicle: bool = false
var mission_stage: int = 0
var cash: int = 250
var health: int = 100
var elapsed: float = 0.0
var toast: String = "Welcome to Naya Nagar — visit the chai stall!"
var toast_time: float = 5.0
var move_vector: Vector2 = Vector2.ZERO
var joystick_touch: int = -1
var joystick_origin: Vector2 = Vector2.ZERO
var joystick_current: Vector2 = Vector2.ZERO
var interaction_requested: bool = false
var save_requested: bool = false
var camera_pos: Vector2 = Vector2.ZERO
var screen_size: Vector2 = Vector2(480.0, 1066.0)
var font: Font
var roads: Array[Rect2] = []
var building_rects: Array[Rect2] = []
var building_data: Array[Dictionary] = []
var tree_data: Array[Dictionary] = []
var lamp_positions: Array[Vector2] = []
var decor_data: Array[Dictionary] = []
var npc_data: Array[Dictionary] = []
var chai_rect: Rect2 = Rect2(1530.0, 1370.0, 180.0, 135.0)
var chai_target: Vector2 = Vector2(1620.0, 1495.0)
var station_target: Vector2 = Vector2(2010.0, 1250.0)

func _ready() -> void:
    font = ThemeDB.fallback_font
    _load_art()
    _build_city()
    _load_game()
    set_process(true)
    set_process_input(true)

func _load_art() -> void:
    var names: Array[String] = [
        "chai_stall", "kirana_shop", "house_terrace", "small_temple",
        "banyan_tree", "neem_tree", "street_lamp", "vegetable_cart", "flower_cart",
        "auto_rickshaw", "scooter", "motorcycle", "hatchback", "player_kurta",
        "pedestrian_sari", "pedestrian_student", "pedestrian_vendor",
        "pedestrian_shopkeeper", "pedestrian_elder", "pedestrian_salwar",
        "pedestrian_delivery", "grass_tile", "asphalt_tile", "sidewalk_tile",
        "dirt_tile", "hindi_sign"
    ]
    for asset_name in names:
        var path: String = "res://assets/indian/" + str(asset_name) + ".png"
        if ResourceLoader.exists(path):
            var tex: Texture2D = load(path) as Texture2D
            if tex != null:
                textures[asset_name] = tex

func _add_building(center: Vector2, sprite_name: String, draw_size: Vector2, hitbox: Rect2) -> void:
    building_data.append({"center": center, "sprite": sprite_name, "size": draw_size})
    building_rects.append(hitbox)

func _build_city() -> void:
    roads = [
        Rect2(1160.0, 0.0, 190.0, WORLD_SIZE.y),
        Rect2(2180.0, 0.0, 175.0, WORLD_SIZE.y),
        Rect2(0.0, 1120.0, WORLD_SIZE.x, 180.0),
        Rect2(0.0, 2160.0, WORLD_SIZE.x, 180.0),
        Rect2(0.0, 3050.0, WORLD_SIZE.x, 150.0),
        Rect2(450.0, 0.0, 112.0, 1120.0),
        Rect2(0.0, 670.0, 1160.0, 104.0),
        Rect2(2440.0, 0.0, 110.0, 1120.0),
        Rect2(2440.0, 1300.0, 110.0, 860.0),
        Rect2(2440.0, 2340.0, 110.0, 710.0)
    ]
    _add_building(Vector2(300, 320), "small_temple", Vector2(235, 285), Rect2(235, 300, 130, 130))
    _add_building(Vector2(760, 350), "house_terrace", Vector2(270, 220), Rect2(675, 315, 170, 140))
    _add_building(Vector2(760, 875), "kirana_shop", Vector2(275, 235), Rect2(670, 835, 180, 140))
    _add_building(Vector2(300, 880), "house_terrace", Vector2(245, 205), Rect2(225, 850, 150, 135))
    _add_building(Vector2(1580, 350), "house_terrace", Vector2(270, 220), Rect2(1495, 315, 170, 140))
    _add_building(Vector2(1940, 350), "kirana_shop", Vector2(275, 235), Rect2(1850, 315, 180, 140))
    _add_building(Vector2(1580, 835), "house_terrace", Vector2(250, 210), Rect2(1500, 800, 160, 135))
    _add_building(Vector2(1940, 835), "house_terrace", Vector2(250, 210), Rect2(1860, 800, 160, 135))
    _add_building(Vector2(300, 1510), "house_terrace", Vector2(255, 215), Rect2(220, 1475, 160, 140))
    _add_building(Vector2(760, 1550), "kirana_shop", Vector2(280, 235), Rect2(670, 1510, 180, 140))
    _add_building(Vector2(300, 1870), "house_terrace", Vector2(250, 215), Rect2(220, 1835, 160, 140))
    _add_building(Vector2(760, 1870), "small_temple", Vector2(190, 235), Rect2(700, 1830, 120, 135))
    _add_building(Vector2(1620, 1460), "chai_stall", Vector2(335, 280), chai_rect)
    _add_building(Vector2(1940, 1530), "house_terrace", Vector2(260, 215), Rect2(1855, 1495, 170, 140))
    _add_building(Vector2(1940, 1880), "kirana_shop", Vector2(275, 235), Rect2(1850, 1840, 180, 140))
    _add_building(Vector2(1620, 1880), "house_terrace", Vector2(255, 215), Rect2(1540, 1845, 160, 140))
    _add_building(Vector2(1430, 1880), "kirana_shop", Vector2(205, 180), Rect2(1365, 1850, 130, 110))
    _add_building(Vector2(1740, 1760), "house_terrace", Vector2(220, 185), Rect2(1670, 1730, 140, 110))
    _add_building(Vector2(300, 2500), "house_terrace", Vector2(250, 210), Rect2(220, 2465, 160, 135))
    _add_building(Vector2(760, 2500), "kirana_shop", Vector2(275, 235), Rect2(670, 2460, 180, 140))
    _add_building(Vector2(300, 2820), "house_terrace", Vector2(245, 210), Rect2(220, 2785, 155, 135))
    _add_building(Vector2(760, 2820), "house_terrace", Vector2(245, 210), Rect2(680, 2785, 155, 135))
    _add_building(Vector2(1580, 2500), "small_temple", Vector2(205, 250), Rect2(1515, 2460, 130, 135))
    _add_building(Vector2(1940, 2500), "house_terrace", Vector2(255, 210), Rect2(1860, 2465, 160, 135))
    _add_building(Vector2(1580, 2820), "house_terrace", Vector2(250, 210), Rect2(1500, 2785, 160, 135))
    _add_building(Vector2(1940, 2820), "kirana_shop", Vector2(275, 235), Rect2(1850, 2780, 180, 140))
    _add_building(Vector2(2670, 400), "house_terrace", Vector2(240, 205), Rect2(2595, 365, 150, 130))
    _add_building(Vector2(2670, 900), "kirana_shop", Vector2(255, 220), Rect2(2590, 865, 160, 135))
    _add_building(Vector2(2670, 1600), "house_terrace", Vector2(245, 210), Rect2(2590, 1565, 160, 135))
    _add_building(Vector2(2670, 2640), "kirana_shop", Vector2(255, 220), Rect2(2590, 2605, 160, 135))

    tree_data.clear()
    for p in [Vector2(115,480),Vector2(920,450),Vector2(1020,850),Vector2(1020,1000),Vector2(100,1050),Vector2(900,1060),Vector2(1450,500),Vector2(2100,500),Vector2(1450,1000),Vector2(2100,1000),Vector2(100,1380),Vector2(930,1380),Vector2(1030,2040),Vector2(1450,2040),Vector2(2100,2040),Vector2(100,2380),Vector2(930,2390),Vector2(1030,2930),Vector2(1450,2940),Vector2(2100,2940),Vector2(2600,1200),Vector2(2800,1200),Vector2(2600,2200),Vector2(2800,2200),Vector2(2600,2950),Vector2(2800,2950)]:
        if not _is_on_road(p) and not _near_building(p, 45.0):
            tree_data.append({"pos": p, "sprite": "banyan_tree" if int(p.x + p.y) % 3 == 0 else "neem_tree", "size": Vector2(100, 112) if int(p.x+p.y)%3==0 else Vector2(82, 98)})
    lamp_positions = [Vector2(1060,1030),Vector2(1410,1040),Vector2(2120,1030),Vector2(1060,1330),Vector2(1410,1330),Vector2(2120,1330),Vector2(1060,2070),Vector2(1410,2070),Vector2(2120,2070),Vector2(1060,2390),Vector2(1410,2390),Vector2(2120,2390),Vector2(2600,1080),Vector2(2600,2280)]
    decor_data = [
        {"pos":Vector2(950,585),"sprite":"vegetable_cart","size":Vector2(180,145)},
        {"pos":Vector2(2070,1720),"sprite":"flower_cart","size":Vector2(155,125)},
        {"pos":Vector2(860,2050),"sprite":"vegetable_cart","size":Vector2(155,125)},
        {"pos":Vector2(2060,2940),"sprite":"flower_cart","size":Vector2(150,120)},
        {"pos":Vector2(1415,1400),"sprite":"vegetable_cart","size":Vector2(128,102)},
        {"pos":Vector2(1430,1670),"sprite":"flower_cart","size":Vector2(128,102)}
    ]
    npc_data = []
    var npc_specs: Array[Dictionary] = [
        {"pos":Vector2(890,1140),"sprite":"pedestrian_sari","size":Vector2(52,76)},
        {"pos":Vector2(990,1410),"sprite":"pedestrian_student","size":Vector2(50,74)},
        {"pos":Vector2(1450,1320),"sprite":"pedestrian_vendor","size":Vector2(52,78)},
        {"pos":Vector2(2010,1250),"sprite":"pedestrian_shopkeeper","size":Vector2(56,80)},
        {"pos":Vector2(1840,1640),"sprite":"pedestrian_elder","size":Vector2(54,78)},
        {"pos":Vector2(1415,1510),"sprite":"pedestrian_sari","size":Vector2(50,72)},
        {"pos":Vector2(1470,1650),"sprite":"pedestrian_student","size":Vector2(48,70)},
        {"pos":Vector2(1510,1760),"sprite":"pedestrian_elder","size":Vector2(50,72)},
        {"pos":Vector2(900,2020),"sprite":"pedestrian_salwar","size":Vector2(52,78)},
        {"pos":Vector2(1500,2020),"sprite":"pedestrian_delivery","size":Vector2(52,78)},
        {"pos":Vector2(2000,2040),"sprite":"pedestrian_student","size":Vector2(50,74)},
        {"pos":Vector2(850,2350),"sprite":"pedestrian_sari","size":Vector2(52,76)},
        {"pos":Vector2(1800,2350),"sprite":"pedestrian_vendor","size":Vector2(52,78)},
        {"pos":Vector2(2620,1450),"sprite":"pedestrian_elder","size":Vector2(54,78)},
        {"pos":Vector2(2760,2050),"sprite":"pedestrian_salwar","size":Vector2(52,78)}
    ]
    for i in range(npc_specs.size()):
        var spec: Dictionary = npc_specs[i]
        npc_data.append({"home":spec["pos"],"pos":spec["pos"],"sprite":spec["sprite"],"size":spec["size"],"phase":float(i)*1.37})

func _is_on_road(p: Vector2) -> bool:
    for road in roads:
        if road.has_point(p):
            return true
    return false

func _near_building(p: Vector2, margin: float) -> bool:
    for hitbox in building_rects:
        if hitbox.grow(margin).has_point(p):
            return true
    return chai_rect.grow(margin).has_point(p)

func _blocked(p: Vector2) -> bool:
    if p.x < 24.0 or p.y < 24.0 or p.x > WORLD_SIZE.x - 24.0 or p.y > WORLD_SIZE.y - 24.0:
        return true
    for hitbox in building_rects:
        if hitbox.grow(8.0).has_point(p):
            return true
    return false

func _active_target() -> Vector2:
    return chai_target if mission_stage == 0 else station_target

func _process(delta: float) -> void:
    elapsed += delta
    toast_time = maxf(0.0, toast_time - delta)
    var direction: Vector2 = move_vector
    if Input.is_action_pressed("ui_left"):
        direction.x -= 1.0
    if Input.is_action_pressed("ui_right"):
        direction.x += 1.0
    if Input.is_action_pressed("ui_up"):
        direction.y -= 1.0
    if Input.is_action_pressed("ui_down"):
        direction.y += 1.0
    direction = direction.limit_length()
    if direction.length() > 0.05:
        player_dir = direction.normalized()
        var speed: float = SCOOTER_SPEED if in_vehicle else PLAYER_SPEED
        var candidate: Vector2 = player_pos + direction.normalized() * speed * delta
        if not _blocked(candidate):
            player_pos = candidate
        if in_vehicle:
            scooter_pos = player_pos
    for i in range(npc_data.size()):
        var npc: Dictionary = npc_data[i]
        var home: Vector2 = npc["home"]
        var phase: float = float(npc["phase"])
        npc["pos"] = home + Vector2(sin(elapsed * 0.35 + phase) * 18.0, cos(elapsed * 0.29 + phase) * 10.0)
        npc_data[i] = npc
    if interaction_requested:
        interaction_requested = false
        _interact()
    if save_requested:
        save_requested = false
        _save_game()
        _show_toast("Saved on this device.")
    queue_redraw()

func _interact() -> void:
    if not in_vehicle and player_pos.distance_to(scooter_pos) < 85.0:
        in_vehicle = true
        player_pos = scooter_pos
        _show_toast("Scooter started — drive around Naya Nagar!")
        return
    if in_vehicle:
        in_vehicle = false
        player_pos += Vector2(48.0, 0.0)
        _show_toast("Scooter parked.")
        return
    var target: Vector2 = _active_target()
    if player_pos.distance_to(target) < 170.0:
        if mission_stage == 0:
            mission_stage = 1
            _show_toast("CHAI JOB: deliver tea to the station worker.")
        elif mission_stage == 1:
            mission_stage = 2
            cash += 150
            _show_toast("Delivery complete! You earned ₹150.")
        else:
            _show_toast("Chaiwala: Come back tomorrow for more work!")
    else:
        _show_toast("Walk closer to the glowing gold mission marker.")

func _show_toast(value: String) -> void:
    toast = value
    toast_time = 3.8

func _save_game() -> void:
    var data: Dictionary = {"player_x":player_pos.x,"player_y":player_pos.y,"scooter_x":scooter_pos.x,"scooter_y":scooter_pos.y,"cash":cash,"health":health,"mission_stage":mission_stage,"in_vehicle":in_vehicle}
    var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify(data))
        file.close()

func _load_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var file: FileAccess = FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        return
    var parsed: Variant = JSON.parse_string(file.get_as_text())
    file.close()
    if parsed is Dictionary:
        player_pos = Vector2(float(parsed.get("player_x", player_pos.x)),float(parsed.get("player_y", player_pos.y)))
        scooter_pos = Vector2(float(parsed.get("scooter_x", scooter_pos.x)),float(parsed.get("scooter_y", scooter_pos.y)))
        cash = int(parsed.get("cash", cash))
        health = int(parsed.get("health", health))
        mission_stage = int(parsed.get("mission_stage", mission_stage))
        in_vehicle = bool(parsed.get("in_vehicle", in_vehicle))

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_E or event.keycode == KEY_SPACE:
            interaction_requested = true
        elif event.keycode == KEY_F5:
            save_requested = true
    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < screen_size.x * 0.52 and event.position.y > screen_size.y * 0.60:
                joystick_touch = event.index
                joystick_origin = event.position
                joystick_current = event.position
                _update_joystick()
            elif event.position.x > screen_size.x * 0.68 and event.position.y > screen_size.y * 0.72:
                if event.position.y < screen_size.y - 108.0:
                    interaction_requested = true
                else:
                    save_requested = true
        elif event.index == joystick_touch:
            joystick_touch = -1
            move_vector = Vector2.ZERO
    elif event is InputEventScreenDrag and event.index == joystick_touch:
        joystick_current = event.position
        _update_joystick()

func _update_joystick() -> void:
    var delta: Vector2 = joystick_current - joystick_origin
    move_vector = (delta / 62.0).limit_length()
    if move_vector.length() < 0.14:
        move_vector = Vector2.ZERO

func _draw() -> void:
    screen_size = get_viewport_rect().size
    camera_pos = player_pos - screen_size * 0.5
    camera_pos.x = clampf(camera_pos.x, 0.0, WORLD_SIZE.x - screen_size.x)
    camera_pos.y = clampf(camera_pos.y, 0.0, WORLD_SIZE.y - screen_size.y)
    draw_set_transform(-camera_pos, 0.0, Vector2.ONE)
    _draw_world()
    _draw_world_entities()
    _draw_characters_and_vehicles()
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    _draw_hud()

func _draw_texture_center(name: String, center: Vector2, size: Vector2) -> void:
    if not textures.has(name):
        return
    var tex: Texture2D = textures[name]
    draw_texture_rect(tex, Rect2(center - size * 0.5, size), false)

func _draw_world() -> void:
    draw_rect(Rect2(Vector2.ZERO, WORLD_SIZE), Color("#5b844c"))
    var grass: Texture2D = textures.get("grass_tile")
    if grass != null:
        var start_x: int = int(floor(camera_pos.x / TILE_SIZE) * TILE_SIZE)
        var start_y: int = int(floor(camera_pos.y / TILE_SIZE) * TILE_SIZE)
        var end_x: float = camera_pos.x + screen_size.x + TILE_SIZE
        var end_y: float = camera_pos.y + screen_size.y + TILE_SIZE
        for x in range(start_x, int(end_x), int(TILE_SIZE)):
            for y in range(start_y, int(end_y), int(TILE_SIZE)):
                draw_texture_rect(grass, Rect2(Vector2(x,y),Vector2(TILE_SIZE,TILE_SIZE)),false)
    # A canal on the far-east edge, with a stone embankment and pixel wave marks.
    draw_rect(Rect2(2810.0,0.0,190.0,WORLD_SIZE.y),Color("#397f9b"))
    for y in range(int(camera_pos.y / 58.0) * 58, int(camera_pos.y + screen_size.y + 60.0), 58):
        draw_line(Vector2(2830,y+15),Vector2(2868,y+7),Color("#76b7c2"),3.0)
        draw_line(Vector2(2910,y+38),Vector2(2945,y+31),Color("#5ca5b8"),2.0)
    draw_rect(Rect2(2780.0,0.0,30.0,WORLD_SIZE.y),Color("#c4ad7f"))
    # Sidewalks first, then the dark asphalt road grid.
    for road in roads:
        draw_rect(road.grow(25.0),Color("#c0ab7d"))
        draw_rect(road.grow(13.0),Color("#d2c09a"))
        draw_rect(road,Color("#3b4046"))
        var asphalt: Texture2D = textures.get("asphalt_tile")
        if asphalt != null:
            var clip_left: float = maxf(road.position.x, camera_pos.x - 64.0)
            var clip_right: float = minf(road.end.x, camera_pos.x + screen_size.x + 64.0)
            var clip_top: float = maxf(road.position.y, camera_pos.y - 64.0)
            var clip_bottom: float = minf(road.end.y, camera_pos.y + screen_size.y + 64.0)
            for tx in range(int(floor(clip_left / 64.0) * 64.0), int(clip_right), 64):
                for ty in range(int(floor(clip_top / 64.0) * 64.0), int(clip_bottom), 64):
                    var tile_rect: Rect2 = Rect2(tx, ty, 64.0, 64.0)
                    var clipped: Rect2 = tile_rect.intersection(road)
                    if clipped.size.x > 0.0 and clipped.size.y > 0.0:
                        var source_rect: Rect2 = Rect2(clipped.position.x - tx, clipped.position.y - ty, clipped.size.x, clipped.size.y)
                        draw_texture_rect_region(asphalt, clipped, source_rect)
        if road.size.x > road.size.y:
            var dash_start: int = int(road.position.x)
            var dash_end: int = int(min(road.end.x,camera_pos.x+screen_size.x+100.0))
            for x in range(maxi(dash_start,int(camera_pos.x-100.0)),dash_end,100):
                draw_rect(Rect2(x,road.position.y+road.size.y*0.5-3.0,48.0,6.0),Color("#e7d49c"))
        else:
            var dash_start_y: int = int(road.position.y)
            var dash_end_y: int = int(min(road.end.y,camera_pos.y+screen_size.y+100.0))
            for y in range(maxi(dash_start_y,int(camera_pos.y-100.0)),dash_end_y,100):
                draw_rect(Rect2(road.position.x+road.size.x*0.5-3.0,y,6.0,48.0),Color("#e7d49c"))
    # Crosswalks at the main junctions.
    for center in [Vector2(1255,1120),Vector2(1255,1300),Vector2(2265,1120),Vector2(2265,1300),Vector2(1255,2160),Vector2(1255,2340)]:
        for i in range(5):
            draw_rect(Rect2(center.x-58.0+i*24.0,center.y-5.0,14.0,10.0),Color("#e8dfc2"))
    # Small roadside dirt cut-throughs and courtyards.
    draw_rect(Rect2(550,1380,470,620),Color("#7d955c"))
    draw_rect(Rect2(550,2380,470,580),Color("#7d955c"))
    if textures.has("dirt_tile"):
        var dirt: Texture2D = textures["dirt_tile"]
        for x in range(560,1010,64):
            for y in range(1390,1980,64):
                draw_texture_rect(dirt,Rect2(x,y,64,64),false)
    # Sidewalk slabs and a few storm drains provide scale and surface detail.
    for x in range(100,int(WORLD_SIZE.x),160):
        for road in roads:
            if road.size.x > road.size.y and absf((road.position.y+road.size.y*0.5)-road.position.y) < 10000.0:
                if x >= camera_pos.x-100 and x <= camera_pos.x+screen_size.x+100:
                    draw_line(Vector2(x,road.position.y-20),Vector2(x+55,road.position.y-20),Color("#b3a17d"),1.0)

func _draw_world_entities() -> void:
    # Back-to-front rendering keeps trees and buildings grounded in the world.
    for tree in tree_data:
        var p: Vector2 = tree["pos"]
        _draw_texture_center(str(tree["sprite"]),p,tree["size"])
    for lamp in lamp_positions:
        _draw_texture_center("street_lamp",lamp,Vector2(32,76))
    for building in building_data:
        var center: Vector2 = building["center"]
        var size: Vector2 = building["size"]
        _draw_texture_center(str(building["sprite"]),center,size)
        if str(building["sprite"]) == "kirana_shop":
            draw_rect(Rect2(center.x-42,center.y-size.y*0.28,84,18),Color("#452d28"))
            draw_string(font,Vector2(center.x-36,center.y-size.y*0.28+13),"KIRANA",HORIZONTAL_ALIGNMENT_LEFT,75,10,Color("#f5d58d"))
        elif str(building["sprite"]) == "chai_stall":
            _draw_texture_center("hindi_sign",center+Vector2(0,-size.y*0.31),Vector2(132,34))
    for decor in decor_data:
        _draw_texture_center(str(decor["sprite"]),decor["pos"],decor["size"])
    # Scooter and a moving-market auto are visible in the streets.
    _draw_texture_center("auto_rickshaw",auto_pos,Vector2(106,100))
    _draw_texture_center("scooter",scooter_pos,Vector2(78,96))
    # Mission marker pulses above the current target.
    var target: Vector2 = _active_target()
    var pulse: float = sin(elapsed*3.0)*5.0
    draw_circle(target+Vector2(0,-36+pulse),13.0,Color(1.0,0.78,0.25,0.25))
    draw_circle(target+Vector2(0,-36+pulse),7.0,Color("#ffcf55"))
    draw_string(font,target+Vector2(-4,-32+pulse),"!",HORIZONTAL_ALIGNMENT_LEFT,-1,15,Color("#473027"))

func _draw_characters_and_vehicles() -> void:
    # Pedestrians move within their own sidewalk patch; the worker waits by the station road.
    for npc_value in npc_data:
        var npc: Dictionary = npc_value
        var p: Vector2 = npc["pos"]
        draw_ellipse_shadow(p+Vector2(0,21),Vector2(15,5))
        _draw_texture_center(str(npc["sprite"]),p, npc["size"])
    draw_ellipse_shadow(player_pos+Vector2(0,24),Vector2(16,6))
    if in_vehicle:
        _draw_texture_center("player_kurta",player_pos+Vector2(0,-10),Vector2(43,62))
    else:
        _draw_texture_center("player_kurta",player_pos,Vector2(55,82))

func draw_ellipse_shadow(center: Vector2, size: Vector2) -> void:
    draw_set_transform(center-camera_pos,0.0,Vector2(1.0,0.34))
    draw_circle(Vector2.ZERO,size.x,Color(0,0,0,0.18))
    draw_set_transform(-camera_pos,0.0,Vector2.ONE)

func _draw_hud() -> void:
    # Compact, premium-looking HUD that leaves most of the city visible.
    draw_rect(Rect2(12,12,screen_size.x-24,104),Color(0.10,0.09,0.08,0.88))
    draw_rect(Rect2(12,12,screen_size.x-24,104),Color("#c69a59"),false,2.0)
    draw_string(font,Vector2(25,39),"BHARAT OPEN WORLD  /  NAYA NAGAR",HORIZONTAL_ALIGNMENT_LEFT,screen_size.x-50,15,Color("#f2d59a"))
    draw_string(font,Vector2(25,65),"₹%d     HP %d     %s" % [cash,health,"SCOOTER" if in_vehicle else "ON FOOT"],HORIZONTAL_ALIGNMENT_LEFT,screen_size.x-50,15,Color.WHITE)
    var objective: String = "Talk to the chaiwala" if mission_stage==0 else ("Deliver chai to the station worker" if mission_stage==1 else "Delivery complete  •  +₹150")
    draw_string(font,Vector2(25,96),"MISSION  ›  "+objective,HORIZONTAL_ALIGNMENT_LEFT,screen_size.x-50,13,Color("#b9e8c8"))
    if toast_time > 0.0:
        draw_rect(Rect2(18,130,screen_size.x-36,46),Color(0.07,0.07,0.07,0.78))
        draw_rect(Rect2(18,130,4,46),Color("#e6b760"))
        draw_string(font,Vector2(31,158),toast,HORIZONTAL_ALIGNMENT_LEFT,screen_size.x-62,12,Color.WHITE)
    # Virtual joystick.
    var joy_center: Vector2 = joystick_origin if joystick_touch != -1 else Vector2(82,screen_size.y-128)
    draw_circle(joy_center,48.0,Color(0.06,0.08,0.09,0.48))
    draw_circle(joy_center,46.0,Color(0.88,0.80,0.60,0.34),false,3.0)
    draw_circle(joy_center+(move_vector*27.0),20.0,Color("#dfc89b"))
    draw_circle(joy_center+(move_vector*27.0),20.0,Color("#f4e3bf"),false,2.0)
    # Action and save buttons.
    var action_center: Vector2 = Vector2(screen_size.x-75.0,screen_size.y-150.0)
    var save_center: Vector2 = Vector2(screen_size.x-73.0,screen_size.y-67.0)
    draw_circle(action_center,39.0,Color("#b65d38"))
    draw_circle(action_center,35.0,Color("#d18a4c"),false,3.0)
    draw_string(font,action_center+Vector2(-24,5),"ACTION",HORIZONTAL_ALIGNMENT_LEFT,50,11,Color.WHITE)
    draw_circle(save_center,29.0,Color("#445a71"))
    draw_circle(save_center,26.0,Color("#a7b3bf"),false,2.0)
    draw_string(font,save_center+Vector2(-16,4),"SAVE",HORIZONTAL_ALIGNMENT_LEFT,38,10,Color.WHITE)
    draw_string(font,Vector2(15,screen_size.y-16),"DRAG TO MOVE  •  E INTERACT",HORIZONTAL_ALIGNMENT_LEFT,screen_size.x-30,10,Color(1,1,1,0.75))
