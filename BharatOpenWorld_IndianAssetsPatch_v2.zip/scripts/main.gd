extends Node2D

# Bharat Open World — Naya Nagar visual rebuild (Godot 4.3)
# Asset-based 2D neighbourhood: tile textures, varied storefronts, roads,
# Indian market props, animated pedestrians, parked traffic, and touch controls.

const SAVE_PATH := "user://bharat_save.json"
const WORLD_SIZE := Vector2(2400, 2800)
const PLAYER_SPEED := 155.0
const VEHICLE_SPEED := 245.0
const TILE_SIZE := 32.0

var player_pos := Vector2(1370, 1430)
var player_dir := Vector2.DOWN
var vehicle_pos := Vector2(1425, 1465)
var in_vehicle := false
var mission_stage := 0
var cash := 250
var health := 100
var elapsed := 0.0
var message := "Welcome to Naya Nagar! Talk to the chaiwala."
var message_time := 5.0
var move_vector := Vector2.ZERO
var joystick_touch := -1
var joystick_origin := Vector2.ZERO
var joystick_current := Vector2.ZERO
var interaction_requested := false
var save_requested := false

var npc_positions: Array[Vector2] = []
var npc_home: Array[Vector2] = []
var npc_types: Array[String] = []
var npc_directions: Array[int] = []
var building_rects: Array[Rect2] = []
var building_types: Array[String] = []
var tree_positions: Array[Vector2] = []
var lamp_positions: Array[Vector2] = []
var road_rects: Array[Rect2] = []
var textures: Dictionary = {}
var ui_textures: Dictionary = {}
var font: Font
var sound_player: AudioStreamPlayer
var camera_pos := Vector2.ZERO
var screen_size := Vector2(480, 854)

const CHAI_STALL := Rect2(1190, 1250, 128, 96)
const CHAI_TARGET := Vector2(1255, 1340)
const STATION_TARGET := Vector2(1575, 1640)

func _ready() -> void:
    randomize()
    font = ThemeDB.fallback_font
    sound_player = AudioStreamPlayer.new()
    add_child(sound_player)
    _load_art()
    _build_world()
    _load_game()
    set_process(true)
    set_process_input(true)

func _load_art() -> void:
    var indian_names := [
        "chai_stall", "kirana_shop", "kirana_shop_detail", "house_terrace",
        "clinic_shop", "repair_shop", "small_temple", "vegetable_cart",
        "banyan_tree", "street_cart", "hindi_sign", "street_lamp",
        "grass_tile", "asphalt_tile", "sidewalk_tile",
        "auto_rickshaw", "scooter", "pedestrian_kurta", "pedestrian_sari",
        "pedestrian_vendor", "player_walk",
        "pedestrian_kurta_walk", "pedestrian_sari_walk",
        "pedestrian_vendor_walk", "pedestrian_student_walk"
    ]
    for art_name in indian_names:
        var path := "res://assets/indian/" + art_name + ".png"
        if ResourceLoader.exists(path):
            textures[art_name] = load(path)

    # Only load the Kenney sprites used by the map. These are 16px CC0 sprites,
    # enlarged with nearest-neighbour filtering to match the game's pixel scale.
    var tile_ids := [355, 381, 420, 422, 426, 469, 474, 476, 480]
    for tile_id in tile_ids:
        var tile_path := "res://assets/kenney_rpg_urban/Tiles/tile_%04d.png" % tile_id
        if ResourceLoader.exists(tile_path):
            textures["kenney_%d" % tile_id] = load(tile_path)

    var action_path := "res://assets/ui/buttonRound_brown.png"
    var save_path := "res://assets/ui/buttonRound_blue.png"
    if ResourceLoader.exists(action_path):
        ui_textures["action"] = load(action_path)
    if ResourceLoader.exists(save_path):
        ui_textures["save"] = load(save_path)

func _build_world() -> void:
    road_rects = [
        Rect2(1030, 0, 112, WORLD_SIZE.y),
        Rect2(0, 1120, WORLD_SIZE.x, 112),
        Rect2(1640, 360, 96, 2180),
        Rect2(0, 1720, WORLD_SIZE.x, 88),
        Rect2(0, 2200, WORLD_SIZE.x, 96),
        Rect2(430, 430, 80, 1290),
        Rect2(0, 650, 1030, 80)
    ]

    # Compact city blocks: every structure uses its own sprite and footprint.
    # No storefront is enlarged into a huge repeated rectangle.
    building_rects = [
        Rect2(570, 745, 128, 128), Rect2(720, 745, 128, 128),
        Rect2(1190, 735, 128, 128), Rect2(1340, 735, 128, 128),
        Rect2(570, 900, 128, 128), Rect2(720, 900, 128, 128),
        Rect2(1190, 900, 128, 128), Rect2(1340, 900, 128, 128),
        Rect2(570, 1300, 128, 128), Rect2(720, 1300, 128, 128),
        Rect2(1340, 1280, 128, 128), Rect2(1190, 1480, 128, 128), Rect2(1340, 1480, 128, 128),
        Rect2(1780, 770, 128, 128), Rect2(1930, 770, 128, 128),
        Rect2(1780, 930, 128, 128), Rect2(1930, 930, 128, 128),
        Rect2(570, 1840, 128, 128), Rect2(720, 1840, 128, 128),
        Rect2(1190, 1870, 128, 128), Rect2(1340, 1870, 128, 128),
        Rect2(1780, 1840, 128, 128), Rect2(1930, 1840, 128, 128),
        Rect2(570, 2310, 128, 128), Rect2(720, 2310, 128, 128),
        Rect2(1190, 2320, 128, 128), Rect2(1340, 2320, 128, 128)
    ]
    building_types = [
        "house_terrace", "kirana_shop_detail", "clinic_shop", "repair_shop",
        "house_terrace", "kirana_shop_detail", "house_terrace", "clinic_shop",
        "house_terrace", "small_temple", "kirana_shop_detail", "repair_shop", "house_terrace",
        "house_terrace", "kirana_shop_detail", "clinic_shop", "house_terrace",
        "house_terrace", "kirana_shop_detail", "house_terrace", "repair_shop",
        "house_terrace", "clinic_shop", "house_terrace", "kirana_shop_detail",
        "house_terrace", "clinic_shop"
    ]

    npc_home = [
        Vector2(850, 1070), Vector2(920, 1320), Vector2(1530, 1370),
        Vector2(1520, 1580), Vector2(1370, 1690), Vector2(900, 1600),
        Vector2(1210, 1080), Vector2(1810, 1130), Vector2(1770, 1640),
        Vector2(860, 2020), Vector2(1510, 2010), Vector2(2000, 1640)
    ]
    npc_positions = npc_home.duplicate()
    npc_types = [
        "pedestrian_kurta_walk", "pedestrian_sari_walk", "pedestrian_vendor_walk",
        "pedestrian_student_walk", "pedestrian_kurta_walk", "pedestrian_sari_walk",
        "pedestrian_vendor_walk", "pedestrian_student_walk", "pedestrian_kurta_walk",
        "pedestrian_sari_walk", "pedestrian_vendor_walk", "pedestrian_student_walk"
    ]
    npc_directions = [0, 2, 1, 3, 0, 1, 2, 0, 3, 1, 2, 0]

    tree_positions.clear()
    lamp_positions.clear()
    # Planted trees and lamps in predictable, walkable pockets.
    var fixed_trees := [
        Vector2(570, 560), Vector2(640, 580), Vector2(830, 580),
        Vector2(870, 790), Vector2(900, 850), Vector2(570, 1080),
        Vector2(780, 1080), Vector2(850, 1360), Vector2(930, 1430),
        Vector2(1470, 1060), Vector2(1510, 1090), Vector2(1780, 1120),
        Vector2(1910, 1120), Vector2(570, 1540), Vector2(740, 1560),
        Vector2(860, 1810), Vector2(930, 1870), Vector2(1490, 1850),
        Vector2(1550, 1900), Vector2(1780, 2040), Vector2(1920, 2040),
        Vector2(570, 2110), Vector2(740, 2110), Vector2(850, 2400),
        Vector2(930, 2450), Vector2(1510, 2420), Vector2(1560, 2460)
    ]
    for p in fixed_trees:
        if not _is_on_road(p) and not _near_building(p, 38):
            tree_positions.append(p)
    for p in [
        Vector2(560, 750), Vector2(900, 1010), Vector2(1200, 1090),
        Vector2(1490, 1090), Vector2(1790, 1700), Vector2(1930, 1700),
        Vector2(900, 1810), Vector2(1500, 2180), Vector2(1950, 2180)
    ]:
        if not _is_on_road(p):
            lamp_positions.append(p)

func _is_on_road(p: Vector2) -> bool:
    for road in road_rects:
        if road.has_point(p):
            return true
    return false

func _near_building(p: Vector2, margin: float) -> bool:
    for b in building_rects:
        if b.grow(margin).has_point(p):
            return true
    return CHAI_STALL.grow(margin).has_point(p)

func _blocked(p: Vector2) -> bool:
    if p.x < 24.0 or p.y < 24.0 or p.x > WORLD_SIZE.x - 24.0 or p.y > WORLD_SIZE.y - 24.0:
        return true
    for b in building_rects:
        if b.grow(10.0).has_point(p):
            return true
    if CHAI_STALL.grow(8.0).has_point(p):
        return true
    return false

func _active_target() -> Vector2:
    return CHAI_TARGET if mission_stage == 0 else STATION_TARGET

func _process(delta: float) -> void:
    elapsed += delta
    if message_time > 0.0:
        message_time = maxf(0.0, message_time - delta)

    var input_dir := move_vector
    if Input.is_action_pressed("ui_left"):
        input_dir.x -= 1.0
    if Input.is_action_pressed("ui_right"):
        input_dir.x += 1.0
    if Input.is_action_pressed("ui_up"):
        input_dir.y -= 1.0
    if Input.is_action_pressed("ui_down"):
        input_dir.y += 1.0
    input_dir = input_dir.limit_length()

    if input_dir.length() > 0.05:
        player_dir = input_dir.normalized()
        if absf(player_dir.x) > absf(player_dir.y):
            player_dir = Vector2.RIGHT if player_dir.x > 0.0 else Vector2.LEFT
        else:
            player_dir = Vector2.DOWN if player_dir.y > 0.0 else Vector2.UP

        var speed := VEHICLE_SPEED if in_vehicle else PLAYER_SPEED
        var candidate := player_pos + input_dir.normalized() * speed * delta
        if not _blocked(candidate):
            player_pos = candidate
        if in_vehicle:
            vehicle_pos = player_pos

    for i in range(npc_positions.size()):
        var home: Vector2 = npc_home[i]
        npc_positions[i] = home + Vector2(
            sin(elapsed * 0.42 + float(i) * 1.7) * 20.0,
            cos(elapsed * 0.36 + float(i) * 1.3) * 12.0
        )

    if interaction_requested:
        interaction_requested = false
        _interact()
    if save_requested:
        save_requested = false
        _save_game()
        _play_sound("metalClick")
        _show_message("Game saved on this device.")
    queue_redraw()

func _interact() -> void:
    if not in_vehicle and player_pos.distance_to(vehicle_pos) < 78.0:
        in_vehicle = true
        player_pos = vehicle_pos
        _play_sound("metalClick")
        _show_message("Scooter started. Use the left joystick to ride.")
        return

    if in_vehicle:
        in_vehicle = false
        player_pos += Vector2(44.0, 0.0)
        _show_message("Scooter parked.")
        return

    var target := _active_target()
    if player_pos.distance_to(target) < 155.0:
        if mission_stage == 0:
            mission_stage = 1
            _show_message("Chaiwala: deliver chai to the railway-station worker!")
        elif mission_stage == 1:
            mission_stage = 2
            cash += 150
            _play_sound("handleCoins")
            _show_message("Delivery complete! You earned ₹150.")
        else:
            _show_message("Chaiwala: fresh chai! Come back for more work.")
    else:
        _show_message("Move closer to the yellow mission marker.")

func _play_sound(sound_name: String) -> void:
    var sound_path := "res://assets/audio/" + sound_name + ".ogg"
    if ResourceLoader.exists(sound_path):
        sound_player.stream = load(sound_path)
        sound_player.play()

func _show_message(text_value: String) -> void:
    message = text_value
    message_time = 4.0

func _save_game() -> void:
    var data := {
        "player_x": player_pos.x,
        "player_y": player_pos.y,
        "vehicle_x": vehicle_pos.x,
        "vehicle_y": vehicle_pos.y,
        "cash": cash,
        "health": health,
        "mission_stage": mission_stage,
        "in_vehicle": in_vehicle
    }
    var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if f:
        f.store_string(JSON.stringify(data))
        f.close()

func _load_game() -> void:
    if not FileAccess.file_exists(SAVE_PATH):
        return
    var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
    if not f:
        return
    var parsed = JSON.parse_string(f.get_as_text())
    f.close()
    if typeof(parsed) != TYPE_DICTIONARY:
        return
    player_pos = Vector2(float(parsed.get("player_x", player_pos.x)), float(parsed.get("player_y", player_pos.y)))
    vehicle_pos = Vector2(float(parsed.get("vehicle_x", vehicle_pos.x)), float(parsed.get("vehicle_y", vehicle_pos.y)))
    cash = int(parsed.get("cash", cash))
    health = int(parsed.get("health", health))
    mission_stage = int(parsed.get("mission_stage", mission_stage))
    in_vehicle = bool(parsed.get("in_vehicle", in_vehicle))

func _input(event: InputEvent) -> void:
    if event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_E or event.keycode == KEY_SPACE:
            interaction_requested = true
        elif event.keycode == KEY_F5:
            save_requested = true

    if event is InputEventScreenTouch:
        if event.pressed:
            if event.position.x < screen_size.x * 0.52 and event.position.y > screen_size.y * 0.54:
                joystick_touch = event.index
                joystick_origin = event.position
                joystick_current = event.position
                _update_joystick()
            elif event.position.x > screen_size.x * 0.70 and event.position.y > screen_size.y * 0.54:
                if event.position.y < screen_size.y * 0.79:
                    interaction_requested = true
                else:
                    save_requested = true
        elif event.index == joystick_touch:
            joystick_touch = -1
            move_vector = Vector2.ZERO
    elif event is InputEventScreenDrag and event.index == joystick_touch:
        joystick_current = event.position
        _update_joystick()

func _update_joystick() -> void:
    move_vector = ((joystick_current - joystick_origin) / 58.0).limit_length()
    if move_vector.length() < 0.16:
        move_vector = Vector2.ZERO

func _draw_sprite(name: String, rect: Rect2) -> void:
    var tex = textures.get(name)
    if tex != null:
        draw_texture_rect(tex, rect, false)

func _draw_kenney(tile_id: int, rect: Rect2) -> void:
    var tex = textures.get("kenney_%d" % tile_id)
    if tex != null:
        draw_texture_rect(tex, rect, false)

func _draw_actor(sheet_name: String, pos: Vector2, direction: int, frame: int, size: Vector2 = Vector2(32, 48)) -> void:
    var tex = textures.get(sheet_name)
    if tex == null:
        var fallback_name := "pedestrian_kurta"
        _draw_sprite(fallback_name, Rect2(pos - size * 0.5, size))
        return
    var source := Rect2(float(frame % 4) * 32.0, float(direction % 4) * 48.0, 32.0, 48.0)
    var dest := Rect2(pos.x - size.x * 0.5, pos.y - size.y * 0.5, size.x, size.y)
    draw_texture_rect_region(tex, dest, source)

func _draw_tiled_texture(texture_name: String, area: Rect2, tile_size: float = 32.0) -> void:
    var tex = textures.get(texture_name)
    if tex == null:
        return
    var visible := Rect2(camera_pos, screen_size).grow(tile_size)
    var clipped := area.intersection(visible)
    if not clipped.has_area():
        return
    var sx := int(floor(clipped.position.x / tile_size)) * int(tile_size)
    var sy := int(floor(clipped.position.y / tile_size)) * int(tile_size)
    var ex := int(ceil(clipped.end.x / tile_size)) * int(tile_size)
    var ey := int(ceil(clipped.end.y / tile_size)) * int(tile_size)
    for x in range(sx, ex, int(tile_size)):
        for y in range(sy, ey, int(tile_size)):
            draw_texture_rect(tex, Rect2(float(x), float(y), tile_size, tile_size), false)

func _draw() -> void:
    screen_size = get_viewport_rect().size
    camera_pos = player_pos - screen_size * 0.5
    camera_pos.x = clampf(camera_pos.x, 0.0, WORLD_SIZE.x - screen_size.x)
    camera_pos.y = clampf(camera_pos.y, 0.0, WORLD_SIZE.y - screen_size.y)

    draw_set_transform(-camera_pos, 0.0, Vector2.ONE)
    _draw_world()
    _draw_entities()
    draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
    _draw_hud()

func _draw_world() -> void:
    draw_rect(Rect2(Vector2.ZERO, WORLD_SIZE), Color("#4d9767"))

    # Grass is textured with the supplied Kenney tilepack rather than flat fill.
    _draw_tiled_texture("grass_tile", Rect2(Vector2.ZERO, WORLD_SIZE), TILE_SIZE)
    var start_x := int(floor(camera_pos.x / TILE_SIZE)) * int(TILE_SIZE)
    var start_y := int(floor(camera_pos.y / TILE_SIZE)) * int(TILE_SIZE)
    var end_x := int(minf(camera_pos.x + screen_size.x + TILE_SIZE, WORLD_SIZE.x))
    var end_y := int(minf(camera_pos.y + screen_size.y + TILE_SIZE, WORLD_SIZE.y))
    for x in range(start_x, end_x, int(TILE_SIZE)):
        for y in range(start_y, end_y, int(TILE_SIZE)):
            var grid_x := int(x / TILE_SIZE)
            var grid_y := int(y / TILE_SIZE)
            if (grid_x * 7 + grid_y * 11) % 13 == 0:
                draw_rect(Rect2(x + 7, y + 8, 3, 3), Color("#e4c878"))
                draw_rect(Rect2(x + 12, y + 12, 2, 2), Color("#3e7d53"))
            elif (grid_x + grid_y * 3) % 17 == 0:
                draw_rect(Rect2(x + 21, y + 19, 4, 2), Color("#7db36c"))

    # Sidewalk first, asphalt over it; texture repeats are clipped to the camera.
    for road in road_rects:
        _draw_tiled_texture("sidewalk_tile", road.grow(18.0), TILE_SIZE)
        draw_rect(road, Color("#565b63"))
        _draw_tiled_texture("asphalt_tile", road, TILE_SIZE)

        if road.size.x > road.size.y:
            var from_x := int(maxf(road.position.x, camera_pos.x - TILE_SIZE))
            var to_x := int(minf(road.end.x, camera_pos.x + screen_size.x + TILE_SIZE))
            for xx in range(from_x, to_x, 80):
                draw_rect(Rect2(xx, road.position.y + road.size.y * 0.5 - 2.0, 34.0, 4.0), Color("#f2dca0"))
        else:
            var from_y := int(maxf(road.position.y, camera_pos.y - TILE_SIZE))
            var to_y := int(minf(road.end.y, camera_pos.y + screen_size.y + TILE_SIZE))
            for yy in range(from_y, to_y, 80):
                draw_rect(Rect2(road.position.x + road.size.x * 0.5 - 2.0, yy, 4.0, 34.0), Color("#f2dca0"))

    # Crosswalks and lane arrows make junctions read as streets, not giant blocks.
    _draw_crosswalk_horizontal(1030, 1120, 112)
    _draw_crosswalk_horizontal(1640, 1120, 96)
    _draw_crosswalk_horizontal(1030, 1720, 88)
    _draw_crosswalk_vertical(1030, 650, 80)
    _draw_crosswalk_vertical(1030, 2200, 96)

    # A paved market court links the chai stall, vegetable cart and nearby shops.
    _draw_tiled_texture("sidewalk_tile", Rect2(1165, 1230, 460, 250), TILE_SIZE)
    draw_rect(Rect2(1165, 1230, 460, 250), Color(0.75, 0.66, 0.48, 0.20), false, 2.0)

    # Shop/building sprites have realistic footprints and varied silhouettes.
    for i in range(building_rects.size()):
        var b: Rect2 = building_rects[i]
        draw_rect(Rect2(b.position.x - 5, b.position.y + 8, b.size.x + 10, b.size.y + 4), Color(0, 0, 0, 0.20))
        var kind: String = building_types[i]
        _draw_sprite(kind, b)
        if i % 3 == 1:
            _draw_sprite("hindi_sign", Rect2(b.position.x + 20, b.position.y - 7, 88, 22))

    # Mission landmark and food cart form a small market plaza.
    _draw_sprite("chai_stall", CHAI_STALL)
    _draw_sprite("hindi_sign", Rect2(CHAI_STALL.position.x + 18, CHAI_STALL.position.y - 14, 92, 23))
    _draw_sprite("vegetable_cart", Rect2(1480, 1250, 84, 70))
    _draw_sprite("street_cart", Rect2(1490, 1340, 64, 52))

    # Parked bicycles, benches, bollards and lights add life to empty sidewalks.
    _draw_kenney(469, Rect2(900, 1195, 40, 40))
    _draw_kenney(381, Rect2(855, 1510, 54, 32))
    _draw_kenney(381, Rect2(1500, 1515, 54, 32))
    _draw_kenney(355, Rect2(575, 1155, 90, 24))
    _draw_kenney(355, Rect2(1770, 1148, 90, 24))

    for p in tree_positions:
        _draw_sprite("banyan_tree", Rect2(p.x - 24, p.y - 34, 48, 60))
    for p in lamp_positions:
        _draw_sprite("street_lamp", Rect2(p.x - 10, p.y - 22, 20, 42))

    # A tiny green park with a walking path and garden beds.
    draw_rect(Rect2(770, 1950, 260, 190), Color("#b5a477"))
    draw_rect(Rect2(782, 1962, 236, 166), Color("#438b5a"))
    draw_rect(Rect2(800, 1978, 200, 12), Color("#d4bd8b"))
    draw_rect(Rect2(800, 1978, 12, 130), Color("#d4bd8b"))
    draw_rect(Rect2(988, 1978, 12, 130), Color("#d4bd8b"))
    _draw_kenney(381, Rect2(858, 2025, 52, 30))
    _draw_kenney(381, Rect2(930, 2025, 52, 30))
    _draw_sprite("banyan_tree", Rect2(855, 1970, 60, 72))
    _draw_sprite("banyan_tree", Rect2(930, 2060, 48, 60))

func _draw_crosswalk_horizontal(x_center: float, y: float, road_width: float) -> void:
    for i in range(6):
        draw_rect(Rect2(x_center - 48 + float(i) * 16, y + 12, 10, road_width - 24), Color("#e4e0cb"))

func _draw_crosswalk_vertical(x: float, y_center: float, road_width: float) -> void:
    for i in range(6):
        draw_rect(Rect2(x + 12, y_center - 48 + float(i) * 16, road_width - 24, 10), Color("#e4e0cb"))

func _draw_entities() -> void:
    # Mission marker moves to the station worker after the chai is collected.
    var target := _active_target()
    var marker_y := target.y + sin(elapsed * 3.0) * 4.0
    draw_circle(Vector2(target.x, marker_y - 22), 19, Color(1.0, 0.76, 0.16, 0.18))
    draw_circle(Vector2(target.x, marker_y - 22), 10, Color("#ffe16b"))
    draw_string(font, Vector2(target.x - 4, marker_y - 16), "!", HORIZONTAL_ALIGNMENT_LEFT, -1, 17, Color("#493326"))

    # Parked traffic around the district; all vehicles use the supplied Kenney sprites.
    _draw_kenney(420, Rect2(850, 1015, 42, 30))
    _draw_kenney(426, Rect2(1480, 1015, 42, 30))
    _draw_kenney(474, Rect2(1790, 1670, 42, 30))
    _draw_kenney(480, Rect2(880, 2140, 32, 42))
    _draw_kenney(422, Rect2(1500, 2140, 42, 30))
    _draw_kenney(476, Rect2(1930, 2140, 42, 30))
    _draw_sprite("auto_rickshaw", Rect2(1510, 1165, 42, 54))
    _draw_sprite("scooter", Rect2(vehicle_pos.x - 18, vehicle_pos.y - 26, 36, 52))

    for i in range(npc_positions.size()):
        var frame := int(elapsed * 5.0 + float(i)) % 4
        var direction := npc_directions[i]
        _draw_actor(npc_types[i], npc_positions[i], direction, frame, Vector2(28, 42))

    # Station worker is a separate mission character.
    _draw_actor("pedestrian_vendor_walk", STATION_TARGET, 0, int(elapsed * 4.0) % 4, Vector2(32, 48))

    draw_rect(Rect2(player_pos.x - 13, player_pos.y + 17, 26, 5), Color(0, 0, 0, 0.25))
    if in_vehicle:
        _draw_sprite("scooter", Rect2(player_pos.x - 22, player_pos.y - 28, 44, 56))
        _draw_actor("player_walk", player_pos + Vector2(0, -5), 0, int(elapsed * 7.0) % 4, Vector2(25, 38))
    else:
        var dir_index := 0
        if player_dir == Vector2.UP:
            dir_index = 1
        elif player_dir == Vector2.LEFT:
            dir_index = 2
        elif player_dir == Vector2.RIGHT:
            dir_index = 3
        var frame := int(elapsed * 8.0) % 4 if move_vector.length() > 0.1 else 0
        _draw_actor("player_walk", player_pos, dir_index, frame, Vector2(32, 48))

func _draw_hud() -> void:
    # Compact HUD leaves most of the play area visible on a tall phone screen.
    draw_rect(Rect2(10, 10, screen_size.x - 20, 78), Color(0.045, 0.065, 0.075, 0.92))
    draw_rect(Rect2(10, 10, screen_size.x - 20, 78), Color("#bd8444"), false, 2.0)
    draw_string(font, Vector2(20, 31), "BHARAT OPEN WORLD  •  NAYA NAGAR", HORIZONTAL_ALIGNMENT_LEFT, screen_size.x - 40, 14, Color("#f5d58a"))
    draw_string(font, Vector2(20, 52), "₹%d   HP %d   %s" % [cash, health, "RIDING" if in_vehicle else "ON FOOT"], HORIZONTAL_ALIGNMENT_LEFT, screen_size.x - 40, 13, Color.WHITE)
    var objective := "Mission: Talk to the chaiwala" if mission_stage == 0 else ("Mission: Deliver chai to station worker" if mission_stage == 1 else "Mission complete  •  +₹150")
    draw_string(font, Vector2(20, 74), objective, HORIZONTAL_ALIGNMENT_LEFT, screen_size.x - 40, 11, Color("#b9e8c8"))

    if message_time > 0.0:
        draw_rect(Rect2(16, 100, screen_size.x - 32, 42), Color(0.04, 0.06, 0.08, 0.88))
        draw_string(font, Vector2(24, 124), message, HORIZONTAL_ALIGNMENT_LEFT, screen_size.x - 48, 11, Color.WHITE)

    var joy_center := joystick_origin if joystick_touch != -1 else Vector2(70, screen_size.y - 100)
    draw_circle(joy_center, 37, Color(0.1, 0.13, 0.16, 0.42))
    draw_circle(joy_center + move_vector * 20.0, 16, Color(0.88, 0.86, 0.72, 0.86))

    var action_tex = ui_textures.get("action")
    var save_tex = ui_textures.get("save")
    if action_tex != null:
        draw_texture_rect(action_tex, Rect2(screen_size.x - 88, screen_size.y - 165, 60, 60), false)
    else:
        draw_circle(Vector2(screen_size.x - 58, screen_size.y - 135), 30, Color("#9b6c43"))
    if save_tex != null:
        draw_texture_rect(save_tex, Rect2(screen_size.x - 78, screen_size.y - 88, 48, 48), false)
    else:
        draw_circle(Vector2(screen_size.x - 54, screen_size.y - 64), 24, Color("#607fa5"))
    draw_string(font, Vector2(screen_size.x - 80, screen_size.y - 132), "ACT", HORIZONTAL_ALIGNMENT_LEFT, 45, 10, Color.WHITE)
    draw_string(font, Vector2(screen_size.x - 70, screen_size.y - 59), "SAVE", HORIZONTAL_ALIGNMENT_LEFT, 42, 9, Color.WHITE)
    draw_string(font, Vector2(12, screen_size.y - 12), "WASD / arrows • E interact • F5 save", HORIZONTAL_ALIGNMENT_LEFT, screen_size.x - 24, 9, Color(1, 1, 1, 0.70))
