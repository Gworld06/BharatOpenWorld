# Bharat Open World — Indian Art Patch v2

This is a substantial visual rebuild for the Godot 4.3 project.

## What changed
- Replaced the repeated oversized storefront layout with smaller, varied building footprints and a denser connected neighbourhood.
- Added an Indian market street, temple, kirana shop, clinic, repair shop, terrace homes, vegetable cart and baked Devanagari chai sign.
- Added a four-direction player walk sheet and animated pedestrian sheets.
- Uses Kenney RPG Urban sprites for tiled grass/sidewalk/road texture, trees, benches, lamps, bicycles and parked cars.
- Adds road junction markings, crosswalks, parked traffic, a small park, and more street props.
- Changes the mission target after collecting chai so the player must deliver it to a station worker.
- Reduces HUD size and sets `window/stretch/aspect="expand"` to use more of tall phone displays and address the letterboxing seen in the screenshot.
- Preserves keyboard/touch controls, scooter interaction, save/load, mission cash reward and audio effects.

## Install into the repository from a phone
1. Upload `BharatOpenWorld_IndianAssetsPatch_v2.zip` to the repository root.
2. Open `.github/workflows/android-apk.yml`.
3. In the asset patch step, change `PATCH="BharatOpenWorld_IndianAssetsPatch.zip"` to `PATCH="BharatOpenWorld_IndianAssetsPatch_v2.zip"`.
4. Add this line directly after the line that copies `scripts/main.gd`:
   `cp /tmp/bharat-indian-patch/project.godot project.godot`
5. Keep the rest of the original build workflow. Commit changes and inspect the GitHub Actions run.
6. Download the new artifact only if the build succeeds.

## Important
The ZIP is a build-time patch: the workflow copies its files into the temporary GitHub Actions workspace. It does not automatically commit the extracted files into the repository. The patch has not been executed by Godot in this environment, so the next GitHub Actions run is the required runtime/parser validation. If it fails, use the exact error from the failed step rather than installing that APK.

## Asset note
The included Kenney RPG Urban Pack is CC0 as indicated by its included license. The additional pixel-art sprites in `assets/indian/` are original assets generated for this project.
